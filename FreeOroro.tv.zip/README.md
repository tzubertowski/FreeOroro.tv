## About
This repo contains a userscript that I have been using for quite a while now. It "pops out" the video on ororo.tv, by such it allows you to watch as much of those as you want.

## Installation info
All you need is a userscript manager. I suggest using tampermonkey for Chrome/Chromium based browsers and Greasemonkey for Firefox based ones.
